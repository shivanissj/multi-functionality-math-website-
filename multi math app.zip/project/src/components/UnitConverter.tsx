import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { ArrowRightLeft } from 'lucide-react';

interface ConversionUnit {
  name: string;
  factor: number;
  symbol: string;
}

const conversionCategories = {
  length: {
    name: 'Length',
    units: [
      { name: 'Meters', factor: 1, symbol: 'm' },
      { name: 'Kilometers', factor: 1000, symbol: 'km' },
      { name: 'Centimeters', factor: 0.01, symbol: 'cm' },
      { name: 'Millimeters', factor: 0.001, symbol: 'mm' },
      { name: 'Inches', factor: 0.0254, symbol: 'in' },
      { name: 'Feet', factor: 0.3048, symbol: 'ft' },
      { name: 'Yards', factor: 0.9144, symbol: 'yd' },
      { name: 'Miles', factor: 1609.344, symbol: 'mi' },
    ]
  },
  weight: {
    name: 'Weight',
    units: [
      { name: 'Kilograms', factor: 1, symbol: 'kg' },
      { name: 'Grams', factor: 0.001, symbol: 'g' },
      { name: 'Pounds', factor: 0.453592, symbol: 'lbs' },
      { name: 'Ounces', factor: 0.0283495, symbol: 'oz' },
      { name: 'Tons', factor: 1000, symbol: 't' },
    ]
  },
  temperature: {
    name: 'Temperature',
    units: [
      { name: 'Celsius', factor: 1, symbol: '°C' },
      { name: 'Fahrenheit', factor: 1, symbol: '°F' },
      { name: 'Kelvin', factor: 1, symbol: 'K' },
    ]
  },
  volume: {
    name: 'Volume',
    units: [
      { name: 'Liters', factor: 1, symbol: 'L' },
      { name: 'Milliliters', factor: 0.001, symbol: 'mL' },
      { name: 'Gallons (US)', factor: 3.78541, symbol: 'gal' },
      { name: 'Quarts', factor: 0.946353, symbol: 'qt' },
      { name: 'Pints', factor: 0.473176, symbol: 'pt' },
      { name: 'Cups', factor: 0.236588, symbol: 'cup' },
    ]
  }
};

export const UnitConverter: React.FC = () => {
  const { currentTheme } = useTheme();
  const [selectedCategory, setSelectedCategory] = useState('length');
  const [fromUnit, setFromUnit] = useState(0);
  const [toUnit, setToUnit] = useState(1);
  const [inputValue, setInputValue] = useState('1');
  const [result, setResult] = useState('');

  const currentCategory = conversionCategories[selectedCategory as keyof typeof conversionCategories];

  const convertValue = (value: string, from: ConversionUnit, to: ConversionUnit): string => {
    const numValue = parseFloat(value);
    if (isNaN(numValue)) return '';

    if (selectedCategory === 'temperature') {
      return convertTemperature(numValue, from.name, to.name).toFixed(6);
    }

    const baseValue = numValue * from.factor;
    const convertedValue = baseValue / to.factor;
    return convertedValue.toFixed(6);
  };

  const convertTemperature = (value: number, from: string, to: string): number => {
    let celsius: number;

    // Convert to Celsius first
    switch (from) {
      case 'Celsius':
        celsius = value;
        break;
      case 'Fahrenheit':
        celsius = (value - 32) * 5 / 9;
        break;
      case 'Kelvin':
        celsius = value - 273.15;
        break;
      default:
        celsius = value;
    }

    // Convert from Celsius to target
    switch (to) {
      case 'Celsius':
        return celsius;
      case 'Fahrenheit':
        return celsius * 9 / 5 + 32;
      case 'Kelvin':
        return celsius + 273.15;
      default:
        return celsius;
    }
  };

  React.useEffect(() => {
    if (inputValue && currentCategory.units[fromUnit] && currentCategory.units[toUnit]) {
      const converted = convertValue(inputValue, currentCategory.units[fromUnit], currentCategory.units[toUnit]);
      setResult(converted);
    }
  }, [inputValue, fromUnit, toUnit, selectedCategory]);

  const swapUnits = () => {
    const temp = fromUnit;
    setFromUnit(toUnit);
    setToUnit(temp);
    setInputValue(result || '1');
  };

  return (
    <div 
      className="p-6 rounded-2xl shadow-2xl"
      style={{ backgroundColor: currentTheme.surface, border: `1px solid ${currentTheme.border}` }}
    >
      <h2 className="text-2xl font-bold mb-6" style={{ color: currentTheme.text }}>
        Unit Converter
      </h2>

      <div className="mb-6">
        <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>
          Category
        </label>
        <select
          value={selectedCategory}
          onChange={(e) => {
            setSelectedCategory(e.target.value);
            setFromUnit(0);
            setToUnit(1);
            setInputValue('1');
          }}
          className="w-full p-3 rounded-lg border"
          style={{ 
            backgroundColor: currentTheme.background, 
            color: currentTheme.text,
            borderColor: currentTheme.border
          }}
        >
          {Object.entries(conversionCategories).map(([key, category]) => (
            <option key={key} value={key}>{category.name}</option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>
            From
          </label>
          <select
            value={fromUnit}
            onChange={(e) => setFromUnit(parseInt(e.target.value))}
            className="w-full p-3 rounded-lg border mb-3"
            style={{ 
              backgroundColor: currentTheme.background, 
              color: currentTheme.text,
              borderColor: currentTheme.border
            }}
          >
            {currentCategory.units.map((unit, index) => (
              <option key={index} value={index}>
                {unit.name} ({unit.symbol})
              </option>
            ))}
          </select>
          <input
            type="number"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            className="w-full p-3 rounded-lg border text-lg"
            style={{ 
              backgroundColor: currentTheme.background, 
              color: currentTheme.text,
              borderColor: currentTheme.border
            }}
            placeholder="Enter value"
          />
        </div>

        <div className="flex flex-col">
          <label className="block text-sm font-medium mb-2" style={{ color: currentTheme.textSecondary }}>
            To
          </label>
          <div className="flex-1 flex flex-col">
            <select
              value={toUnit}
              onChange={(e) => setToUnit(parseInt(e.target.value))}
              className="w-full p-3 rounded-lg border mb-3"
              style={{ 
                backgroundColor: currentTheme.background, 
                color: currentTheme.text,
                borderColor: currentTheme.border
              }}
            >
              {currentCategory.units.map((unit, index) => (
                <option key={index} value={index}>
                  {unit.name} ({unit.symbol})
                </option>
              ))}
            </select>
            <div
              className="flex-1 p-3 rounded-lg text-lg font-mono flex items-center"
              style={{ backgroundColor: currentTheme.background, color: currentTheme.primary }}
            >
              {result || '0'}
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={swapUnits}
        className="mt-4 w-full p-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 active:scale-95 flex items-center justify-center gap-2"
        style={{ backgroundColor: currentTheme.primary, color: 'white' }}
      >
        <ArrowRightLeft size={18} />
        Swap Units
      </button>
    </div>
  );
};