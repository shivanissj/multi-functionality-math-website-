import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { History as HistoryIcon, Trash2 } from 'lucide-react';

interface HistoryProps {
  calculations: string[];
  onClear: () => void;
}

export const History: React.FC<HistoryProps> = ({ calculations, onClear }) => {
  const { currentTheme } = useTheme();

  return (
    <div 
      className="p-6 rounded-2xl shadow-2xl"
      style={{ backgroundColor: currentTheme.surface, border: `1px solid ${currentTheme.border}` }}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <HistoryIcon size={24} style={{ color: currentTheme.primary }} />
          <h2 className="text-2xl font-bold" style={{ color: currentTheme.text }}>
            Calculation History
          </h2>
        </div>
        {calculations.length > 0 && (
          <button
            onClick={onClear}
            className="p-2 rounded-lg transition-all duration-200 transform hover:scale-105 active:scale-95"
            style={{ backgroundColor: currentTheme.error, color: 'white' }}
          >
            <Trash2 size={18} />
          </button>
        )}
      </div>

      <div className="space-y-2 max-h-96 overflow-y-auto">
        {calculations.length === 0 ? (
          <p className="text-center py-8" style={{ color: currentTheme.textSecondary }}>
            No calculations yet. Start using the calculator to see your history here.
          </p>
        ) : (
          calculations.slice().reverse().map((calculation, index) => (
            <div 
              key={index}
              className="p-3 rounded-lg font-mono text-sm"
              style={{ backgroundColor: currentTheme.background, color: currentTheme.text }}
            >
              {calculation}
            </div>
          ))
        )}
      </div>
    </div>
  );
};