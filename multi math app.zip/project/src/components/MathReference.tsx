import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { BookOpen } from 'lucide-react';

export const MathReference: React.FC = () => {
  const { currentTheme } = useTheme();

  const formulas = [
    {
      category: 'Basic Algebra',
      items: [
        { name: 'Quadratic Formula', formula: 'x = (-b ± √(b² - 4ac)) / 2a' },
        { name: 'Distance Formula', formula: 'd = √((x₂-x₁)² + (y₂-y₁)²)' },
        { name: 'Slope', formula: 'm = (y₂-y₁) / (x₂-x₁)' },
      ]
    },
    {
      category: 'Geometry',
      items: [
        { name: 'Circle Area', formula: 'A = πr²' },
        { name: 'Circle Circumference', formula: 'C = 2πr' },
        { name: 'Rectangle Area', formula: 'A = l × w' },
        { name: 'Triangle Area', formula: 'A = ½ × b × h' },
        { name: 'Sphere Volume', formula: 'V = (4/3)πr³' },
      ]
    },
    {
      category: 'Trigonometry',
      items: [
        { name: 'Pythagorean Theorem', formula: 'a² + b² = c²' },
        { name: 'Law of Cosines', formula: 'c² = a² + b² - 2ab cos(C)' },
        { name: 'Law of Sines', formula: 'a/sin(A) = b/sin(B) = c/sin(C)' },
      ]
    },
    {
      category: 'Statistics',
      items: [
        { name: 'Mean', formula: 'x̄ = Σx / n' },
        { name: 'Standard Deviation', formula: 'σ = √(Σ(x - μ)² / N)' },
        { name: 'Variance', formula: 'σ² = Σ(x - μ)² / N' },
      ]
    }
  ];

  const constants = [
    { name: 'π (Pi)', value: '3.14159...', description: 'Ratio of circle circumference to diameter' },
    { name: 'e (Euler\'s number)', value: '2.71828...', description: 'Base of natural logarithm' },
    { name: '√2', value: '1.41421...', description: 'Square root of 2' },
    { name: '√3', value: '1.73205...', description: 'Square root of 3' },
    { name: 'φ (Golden ratio)', value: '1.61803...', description: 'Golden ratio' },
  ];

  return (
    <div 
      className="p-6 rounded-2xl shadow-2xl"
      style={{ backgroundColor: currentTheme.surface, border: `1px solid ${currentTheme.border}` }}
    >
      <div className="flex items-center gap-3 mb-6">
        <BookOpen size={24} style={{ color: currentTheme.primary }} />
        <h2 className="text-2xl font-bold" style={{ color: currentTheme.text }}>
          Math Reference
        </h2>
      </div>

      <div className="space-y-6">
        {/* Formulas */}
        <div>
          <h3 className="text-xl font-semibold mb-4" style={{ color: currentTheme.text }}>
            Common Formulas
          </h3>
          <div className="space-y-4">
            {formulas.map((category) => (
              <div key={category.category}>
                <h4 className="text-lg font-medium mb-2" style={{ color: currentTheme.primary }}>
                  {category.category}
                </h4>
                <div className="grid gap-2">
                  {category.items.map((item) => (
                    <div 
                      key={item.name}
                      className="p-3 rounded-lg"
                      style={{ backgroundColor: currentTheme.background }}
                    >
                      <div className="flex justify-between items-center">
                        <span className="font-medium" style={{ color: currentTheme.text }}>
                          {item.name}
                        </span>
                        <span className="font-mono text-sm" style={{ color: currentTheme.primary }}>
                          {item.formula}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Constants */}
        <div>
          <h3 className="text-xl font-semibold mb-4" style={{ color: currentTheme.text }}>
            Mathematical Constants
          </h3>
          <div className="grid gap-2">
            {constants.map((constant) => (
              <div 
                key={constant.name}
                className="p-3 rounded-lg"
                style={{ backgroundColor: currentTheme.background }}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-medium" style={{ color: currentTheme.text }}>
                      {constant.name}
                    </span>
                    <p className="text-sm mt-1" style={{ color: currentTheme.textSecondary }}>
                      {constant.description}
                    </p>
                  </div>
                  <span className="font-mono text-sm" style={{ color: currentTheme.primary }}>
                    {constant.value}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};