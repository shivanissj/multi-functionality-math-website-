import React from 'react';
import { useTheme } from '../context/ThemeContext';
import { Palette } from 'lucide-react';

export const ThemeSelector: React.FC = () => {
  const { currentTheme, themeName, setTheme, availableThemes } = useTheme();

  return (
    <div 
      className="p-6 rounded-2xl shadow-2xl"
      style={{ backgroundColor: currentTheme.surface, border: `1px solid ${currentTheme.border}` }}
    >
      <div className="flex items-center gap-3 mb-4">
        <Palette size={24} style={{ color: currentTheme.primary }} />
        <h2 className="text-2xl font-bold" style={{ color: currentTheme.text }}>
          Theme Selector
        </h2>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {availableThemes.map((theme) => (
          <button
            key={theme}
            onClick={() => setTheme(theme)}
            className={`p-4 rounded-xl border-2 transition-all duration-200 transform hover:scale-105 ${
              themeName === theme ? 'ring-2' : ''
            }`}
            style={{
              borderColor: themeName === theme ? currentTheme.primary : currentTheme.border,
              ringColor: currentTheme.primary,
            }}
          >
            <div className="text-center">
              <div className="h-8 w-full rounded-lg mb-2 flex">
                <div 
                  className="flex-1 rounded-l-lg"
                  style={{ backgroundColor: currentTheme.primary }}
                />
                <div 
                  className="flex-1"
                  style={{ backgroundColor: currentTheme.secondary }}
                />
                <div 
                  className="flex-1 rounded-r-lg"
                  style={{ backgroundColor: currentTheme.accent }}
                />
              </div>
              <p className="font-medium capitalize" style={{ color: currentTheme.text }}>
                {theme}
              </p>
            </div>
          </button>
        ))}
      </div>

      <div className="mt-6 p-4 rounded-lg" style={{ backgroundColor: currentTheme.background }}>
        <h3 className="font-semibold mb-2" style={{ color: currentTheme.text }}>
          Current Theme: {currentTheme.name}
        </h3>
        <div className="grid grid-cols-3 gap-2 text-sm">
          <div>
            <p style={{ color: currentTheme.textSecondary }}>Primary</p>
            <div 
              className="h-6 w-full rounded mt-1"
              style={{ backgroundColor: currentTheme.primary }}
            />
          </div>
          <div>
            <p style={{ color: currentTheme.textSecondary }}>Secondary</p>
            <div 
              className="h-6 w-full rounded mt-1"
              style={{ backgroundColor: currentTheme.secondary }}
            />
          </div>
          <div>
            <p style={{ color: currentTheme.textSecondary }}>Accent</p>
            <div 
              className="h-6 w-full rounded mt-1"
              style={{ backgroundColor: currentTheme.accent }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};