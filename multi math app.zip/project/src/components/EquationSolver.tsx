import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { Calculator } from 'lucide-react';

export const EquationSolver: React.FC = () => {
  const { currentTheme } = useTheme();
  const [equation, setEquation] = useState('');
  const [solution, setSolution] = useState('');
  const [steps, setSteps] = useState<string[]>([]);

  const solveLinearEquation = (eq: string): { solution: string; steps: string[] } => {
    try {
      // Simple linear equation solver (ax + b = c format)
      const cleanEq = eq.replace(/\s/g, '').toLowerCase();
      
      // Split by equals sign
      const [left, right] = cleanEq.split('=');
      if (!left || !right) {
        throw new Error('Invalid equation format');
      }

      // Parse right side (should be a number)
      const rightValue = parseFloat(right);
      if (isNaN(rightValue)) {
        throw new Error('Right side must be a number');
      }

      // Parse left side (ax + b format)
      const leftSide = left;
      
      // Extract coefficient of x and constant
      let coefficient = 0;
      let constant = 0;
      
      // Simple regex patterns
      const xTermMatch = leftSide.match(/([+-]?\d*\.?\d*)x/);
      const constantMatch = leftSide.match(/([+-]?\d+\.?\d*)(?!.*x)/);
      
      if (xTermMatch) {
        const coeff = xTermMatch[1];
        if (coeff === '' || coeff === '+') {
          coefficient = 1;
        } else if (coeff === '-') {
          coefficient = -1;
        } else {
          coefficient = parseFloat(coeff);
        }
      }
      
      if (constantMatch) {
        constant = parseFloat(constantMatch[1]);
      }

      if (coefficient === 0) {
        throw new Error('No x variable found');
      }

      // Solve: ax + b = c => x = (c - b) / a
      const x = (rightValue - constant) / coefficient;
      
      const solutionSteps = [
        `Original equation: ${equation}`,
        `Rearrange: ${coefficient}x = ${rightValue} - ${constant}`,
        `Simplify: ${coefficient}x = ${rightValue - constant}`,
        `Divide by ${coefficient}: x = ${rightValue - constant} / ${coefficient}`,
        `Solution: x = ${x}`
      ];

      return {
        solution: `x = ${x}`,
        steps: solutionSteps
      };
    } catch (error) {
      return {
        solution: 'Error: Unable to solve equation',
        steps: ['Please enter a linear equation in the format: ax + b = c']
      };
    }
  };

  const solveQuadratic = (a: number, b: number, c: number): { solution: string; steps: string[] } => {
    const discriminant = b * b - 4 * a * c;
    const solutionSteps = [
      `Quadratic equation: ${a}x² + ${b}x + ${c} = 0`,
      `Using quadratic formula: x = (-b ± √(b² - 4ac)) / 2a`,
      `Calculate discriminant: Δ = ${b}² - 4(${a})(${c}) = ${discriminant}`
    ];

    if (discriminant > 0) {
      const x1 = (-b + Math.sqrt(discriminant)) / (2 * a);
      const x2 = (-b - Math.sqrt(discriminant)) / (2 * a);
      solutionSteps.push(`Two real solutions:`);
      solutionSteps.push(`x₁ = ${x1.toFixed(4)}`);
      solutionSteps.push(`x₂ = ${x2.toFixed(4)}`);
      return { solution: `x₁ = ${x1.toFixed(4)}, x₂ = ${x2.toFixed(4)}`, steps: solutionSteps };
    } else if (discriminant === 0) {
      const x = -b / (2 * a);
      solutionSteps.push(`One real solution: x = ${x.toFixed(4)}`);
      return { solution: `x = ${x.toFixed(4)}`, steps: solutionSteps };
    } else {
      const realPart = -b / (2 * a);
      const imagPart = Math.sqrt(-discriminant) / (2 * a);
      solutionSteps.push(`Two complex solutions:`);
      solutionSteps.push(`x₁ = ${realPart.toFixed(4)} + ${imagPart.toFixed(4)}i`);
      solutionSteps.push(`x₂ = ${realPart.toFixed(4)} - ${imagPart.toFixed(4)}i`);
      return { 
        solution: `x₁ = ${realPart.toFixed(4)} + ${imagPart.toFixed(4)}i, x₂ = ${realPart.toFixed(4)} - ${imagPart.toFixed(4)}i`, 
        steps: solutionSteps 
      };
    }
  };

  const handleSolve = () => {
    if (!equation.trim()) return;

    const result = solveLinearEquation(equation);
    setSolution(result.solution);
    setSteps(result.steps);
  };

  const [quadA, setQuadA] = useState('1');
  const [quadB, setQuadB] = useState('0');
  const [quadC, setQuadC] = useState('0');

  const handleQuadraticSolve = () => {
    const a = parseFloat(quadA);
    const b = parseFloat(quadB);
    const c = parseFloat(quadC);

    if (isNaN(a) || isNaN(b) || isNaN(c) || a === 0) {
      setSolution('Error: Invalid coefficients (a cannot be 0)');
      setSteps(['Please enter valid coefficients for the quadratic equation']);
      return;
    }

    const result = solveQuadratic(a, b, c);
    setSolution(result.solution);
    setSteps(result.steps);
  };

  return (
    <div 
      className="p-6 rounded-2xl shadow-2xl space-y-6"
      style={{ backgroundColor: currentTheme.surface, border: `1px solid ${currentTheme.border}` }}
    >
      <div className="flex items-center gap-3">
        <Calculator size={24} style={{ color: currentTheme.primary }} />
        <h2 className="text-2xl font-bold" style={{ color: currentTheme.text }}>
          Equation Solver
        </h2>
      </div>

      {/* Linear Equation Solver */}
      <div>
        <h3 className="text-lg font-semibold mb-3" style={{ color: currentTheme.text }}>
          Linear Equation (ax + b = c)
        </h3>
        <div className="flex gap-3 mb-3">
          <input
            type="text"
            value={equation}
            onChange={(e) => setEquation(e.target.value)}
            placeholder="e.g., 2x + 3 = 7"
            className="flex-1 p-3 rounded-lg border"
            style={{ 
              backgroundColor: currentTheme.background, 
              color: currentTheme.text,
              borderColor: currentTheme.border
            }}
          />
          <button
            onClick={handleSolve}
            className="px-6 py-3 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 active:scale-95"
            style={{ backgroundColor: currentTheme.primary, color: 'white' }}
          >
            Solve
          </button>
        </div>
      </div>

      {/* Quadratic Equation Solver */}
      <div>
        <h3 className="text-lg font-semibold mb-3" style={{ color: currentTheme.text }}>
          Quadratic Equation (ax² + bx + c = 0)
        </h3>
        <div className="grid grid-cols-4 gap-3 mb-3">
          <div>
            <label className="block text-sm mb-1" style={{ color: currentTheme.textSecondary }}>a</label>
            <input
              type="number"
              value={quadA}
              onChange={(e) => setQuadA(e.target.value)}
              className="w-full p-2 rounded-lg border"
              style={{ 
                backgroundColor: currentTheme.background, 
                color: currentTheme.text,
                borderColor: currentTheme.border
              }}
            />
          </div>
          <div>
            <label className="block text-sm mb-1" style={{ color: currentTheme.textSecondary }}>b</label>
            <input
              type="number"
              value={quadB}
              onChange={(e) => setQuadB(e.target.value)}
              className="w-full p-2 rounded-lg border"
              style={{ 
                backgroundColor: currentTheme.background, 
                color: currentTheme.text,
                borderColor: currentTheme.border
              }}
            />
          </div>
          <div>
            <label className="block text-sm mb-1" style={{ color: currentTheme.textSecondary }}>c</label>
            <input
              type="number"
              value={quadC}
              onChange={(e) => setQuadC(e.target.value)}
              className="w-full p-2 rounded-lg border"
              style={{ 
                backgroundColor: currentTheme.background, 
                color: currentTheme.text,
                borderColor: currentTheme.border
              }}
            />
          </div>
          <button
            onClick={handleQuadraticSolve}
            className="px-4 py-2 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 active:scale-95 self-end"
            style={{ backgroundColor: currentTheme.secondary, color: 'white' }}
          >
            Solve
          </button>
        </div>
      </div>

      {/* Solution Display */}
      {solution && (
        <div 
          className="p-4 rounded-lg"
          style={{ backgroundColor: currentTheme.background }}
        >
          <h4 className="font-semibold mb-2" style={{ color: currentTheme.text }}>Solution:</h4>
          <p className="text-lg font-mono mb-3" style={{ color: currentTheme.primary }}>
            {solution}
          </p>
          
          {steps.length > 0 && (
            <div>
              <h5 className="font-semibold mb-2" style={{ color: currentTheme.text }}>Steps:</h5>
              <ol className="space-y-1">
                {steps.map((step, index) => (
                  <li key={index} className="text-sm" style={{ color: currentTheme.textSecondary }}>
                    {index + 1}. {step}
                  </li>
                ))}
              </ol>
            </div>
          )}
        </div>
      )}
    </div>
  );
};