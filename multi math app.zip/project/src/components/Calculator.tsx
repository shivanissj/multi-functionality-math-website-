import React, { useState } from 'react';
import { useTheme } from '../context/ThemeContext';
import { Delete, History } from 'lucide-react';

interface CalculatorProps {
  onAddToHistory: (calculation: string) => void;
}

export const Calculator: React.FC<CalculatorProps> = ({ onAddToHistory }) => {
  const { currentTheme } = useTheme();
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);

  const calculate = (firstOperand: number, secondOperand: number, operation: string): number => {
    switch (operation) {
      case '+':
        return firstOperand + secondOperand;
      case '-':
        return firstOperand - secondOperand;
      case '×':
        return firstOperand * secondOperand;
      case '÷':
        return secondOperand !== 0 ? firstOperand / secondOperand : NaN;
      case '^':
        return Math.pow(firstOperand, secondOperand);
      case '%':
        return firstOperand % secondOperand;
      default:
        return secondOperand;
    }
  };

  const performOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(inputValue);
    } else if (operation) {
      const currentValue = previousValue || 0;
      const newValue = calculate(currentValue, inputValue, operation);

      const calculation = `${currentValue} ${operation} ${inputValue} = ${newValue}`;
      onAddToHistory(calculation);

      setDisplay(String(newValue));
      setPreviousValue(newValue);
    }

    setWaitingForOperand(true);
    setOperation(nextOperation);
  };

  const inputNumber = (num: string) => {
    if (waitingForOperand) {
      setDisplay(num);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const inputDecimal = () => {
    if (waitingForOperand) {
      setDisplay('0.');
      setWaitingForOperand(false);
    } else if (display.indexOf('.') === -1) {
      setDisplay(display + '.');
    }
  };

  const clear = () => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForOperand(false);
  };

  const clearEntry = () => {
    setDisplay('0');
  };

  const performFunction = (func: string) => {
    const inputValue = parseFloat(display);
    let result: number;
    let calculation: string;

    switch (func) {
      case '√':
        result = Math.sqrt(inputValue);
        calculation = `√${inputValue} = ${result}`;
        break;
      case 'x²':
        result = inputValue * inputValue;
        calculation = `${inputValue}² = ${result}`;
        break;
      case '1/x':
        result = inputValue !== 0 ? 1 / inputValue : NaN;
        calculation = `1/${inputValue} = ${result}`;
        break;
      case 'sin':
        result = Math.sin(inputValue * Math.PI / 180);
        calculation = `sin(${inputValue}°) = ${result}`;
        break;
      case 'cos':
        result = Math.cos(inputValue * Math.PI / 180);
        calculation = `cos(${inputValue}°) = ${result}`;
        break;
      case 'tan':
        result = Math.tan(inputValue * Math.PI / 180);
        calculation = `tan(${inputValue}°) = ${result}`;
        break;
      case 'ln':
        result = inputValue > 0 ? Math.log(inputValue) : NaN;
        calculation = `ln(${inputValue}) = ${result}`;
        break;
      case 'log':
        result = inputValue > 0 ? Math.log10(inputValue) : NaN;
        calculation = `log(${inputValue}) = ${result}`;
        break;
      default:
        return;
    }

    onAddToHistory(calculation);
    setDisplay(String(result));
    setWaitingForOperand(true);
  };

  const Button: React.FC<{
    onClick: () => void;
    className?: string;
    children: React.ReactNode;
    variant?: 'primary' | 'secondary' | 'operation' | 'function';
  }> = ({ onClick, className = '', children, variant = 'secondary' }) => {
    const getButtonStyles = () => {
      const baseStyles = 'h-12 rounded-lg font-semibold transition-all duration-200 transform hover:scale-105 active:scale-95';
      
      switch (variant) {
        case 'primary':
          return `${baseStyles} text-white shadow-lg hover:shadow-xl`;
        case 'operation':
          return `${baseStyles} text-white shadow-lg hover:shadow-xl`;
        case 'function':
          return `${baseStyles} text-sm shadow-md hover:shadow-lg`;
        default:
          return `${baseStyles} shadow-md hover:shadow-lg`;
      }
    };

    const getButtonColors = () => {
      switch (variant) {
        case 'primary':
          return { backgroundColor: currentTheme.accent, ':hover': { backgroundColor: currentTheme.primary } };
        case 'operation':
          return { backgroundColor: currentTheme.primary, ':hover': { backgroundColor: currentTheme.buttonHover } };
        case 'function':
          return { backgroundColor: currentTheme.secondary, color: 'white' };
        default:
          return { backgroundColor: currentTheme.buttonSecondary, color: currentTheme.text };
      }
    };

    return (
      <button
        onClick={onClick}
        className={`${getButtonStyles()} ${className}`}
        style={getButtonColors()}
      >
        {children}
      </button>
    );
  };

  return (
    <div 
      className="p-6 rounded-2xl shadow-2xl"
      style={{ backgroundColor: currentTheme.surface, border: `1px solid ${currentTheme.border}` }}
    >
      <div 
        className="mb-6 p-4 rounded-xl text-right text-3xl font-mono"
        style={{ backgroundColor: currentTheme.background, color: currentTheme.text }}
      >
        {display}
      </div>

      <div className="grid grid-cols-4 gap-3 mb-4">
        <Button variant="function" onClick={() => performFunction('sin')}>sin</Button>
        <Button variant="function" onClick={() => performFunction('cos')}>cos</Button>
        <Button variant="function" onClick={() => performFunction('tan')}>tan</Button>
        <Button variant="function" onClick={() => performFunction('ln')}>ln</Button>
        
        <Button variant="function" onClick={() => performFunction('√')}>√</Button>
        <Button variant="function" onClick={() => performFunction('x²')}>x²</Button>
        <Button variant="function" onClick={() => performFunction('1/x')}>1/x</Button>
        <Button variant="function" onClick={() => performFunction('log')}>log</Button>
      </div>

      <div className="grid grid-cols-4 gap-3">
        <Button onClick={clear}>AC</Button>
        <Button onClick={clearEntry}>CE</Button>
        <Button onClick={() => performOperation('%')}>%</Button>
        <Button variant="operation" onClick={() => performOperation('÷')}>÷</Button>

        <Button onClick={() => inputNumber('7')}>7</Button>
        <Button onClick={() => inputNumber('8')}>8</Button>
        <Button onClick={() => inputNumber('9')}>9</Button>
        <Button variant="operation" onClick={() => performOperation('×')}>×</Button>

        <Button onClick={() => inputNumber('4')}>4</Button>
        <Button onClick={() => inputNumber('5')}>5</Button>
        <Button onClick={() => inputNumber('6')}>6</Button>
        <Button variant="operation" onClick={() => performOperation('-')}>−</Button>

        <Button onClick={() => inputNumber('1')}>1</Button>
        <Button onClick={() => inputNumber('2')}>2</Button>
        <Button onClick={() => inputNumber('3')}>3</Button>
        <Button variant="operation" onClick={() => performOperation('+')}>+</Button>

        <Button onClick={() => inputNumber('0')} className="col-span-2">0</Button>
        <Button onClick={inputDecimal}>.</Button>
        <Button variant="primary" onClick={() => performOperation('=')}>=</Button>
      </div>
    </div>
  );
};