import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface Theme {
  name: string;
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  text: string;
  textSecondary: string;
  border: string;
  buttonPrimary: string;
  buttonSecondary: string;
  buttonHover: string;
  error: string;
  success: string;
  warning: string;
}

const themes: Record<string, Theme> = {
  light: {
    name: 'Light',
    primary: '#3B82F6',
    secondary: '#10B981',
    accent: '#F59E0B',
    background: '#F8FAFC',
    surface: '#FFFFFF',
    text: '#1F2937',
    textSecondary: '#6B7280',
    border: '#E5E7EB',
    buttonPrimary: '#3B82F6',
    buttonSecondary: '#F3F4F6',
    buttonHover: '#2563EB',
    error: '#EF4444',
    success: '#10B981',
    warning: '#F59E0B',
  },
  dark: {
    name: 'Dark',
    primary: '#60A5FA',
    secondary: '#34D399',
    accent: '#FBBF24',
    background: '#0F172A',
    surface: '#1E293B',
    text: '#F1F5F9',
    textSecondary: '#94A3B8',
    border: '#334155',
    buttonPrimary: '#60A5FA',
    buttonSecondary: '#374151',
    buttonHover: '#3B82F6',
    error: '#F87171',
    success: '#34D399',
    warning: '#FBBF24',
  },
  ocean: {
    name: 'Ocean',
    primary: '#0EA5E9',
    secondary: '#06B6D4',
    accent: '#8B5CF6',
    background: '#F0F9FF',
    surface: '#FFFFFF',
    text: '#0C4A6E',
    textSecondary: '#0369A1',
    border: '#BAE6FD',
    buttonPrimary: '#0EA5E9',
    buttonSecondary: '#E0F2FE',
    buttonHover: '#0284C7',
    error: '#DC2626',
    success: '#059669',
    warning: '#D97706',
  },
  sunset: {
    name: 'Sunset',
    primary: '#F97316',
    secondary: '#EF4444',
    accent: '#EC4899',
    background: '#FFF7ED',
    surface: '#FFFFFF',
    text: '#9A3412',
    textSecondary: '#C2410C',
    border: '#FED7AA',
    buttonPrimary: '#F97316',
    buttonSecondary: '#FFF7ED',
    buttonHover: '#EA580C',
    error: '#DC2626',
    success: '#16A34A',
    warning: '#CA8A04',
  },
  forest: {
    name: 'Forest',
    primary: '#16A34A',
    secondary: '#059669',
    accent: '#0D9488',
    background: '#F0FDF4',
    surface: '#FFFFFF',
    text: '#14532D',
    textSecondary: '#166534',
    border: '#BBF7D0',
    buttonPrimary: '#16A34A',
    buttonSecondary: '#F0FDF4',
    buttonHover: '#15803D',
    error: '#DC2626',
    success: '#16A34A',
    warning: '#CA8A04',
  },
  purple: {
    name: 'Purple',
    primary: '#8B5CF6',
    secondary: '#A855F7',
    accent: '#EC4899',
    background: '#FAFAF9',
    surface: '#FFFFFF',
    text: '#581C87',
    textSecondary: '#7C3AED',
    border: '#DDD6FE',
    buttonPrimary: '#8B5CF6',
    buttonSecondary: '#F5F3FF',
    buttonHover: '#7C3AED',
    error: '#DC2626',
    success: '#16A34A',
    warning: '#CA8A04',
  },
};

interface ThemeContextType {
  currentTheme: Theme;
  themeName: string;
  setTheme: (themeName: string) => void;
  availableThemes: string[];
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [themeName, setThemeName] = useState('light');
  const currentTheme = themes[themeName];

  const setTheme = (newThemeName: string) => {
    if (themes[newThemeName]) {
      setThemeName(newThemeName);
    }
  };

  const availableThemes = Object.keys(themes);

  return (
    <ThemeContext.Provider value={{ currentTheme, themeName, setTheme, availableThemes }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};