import React, { useState } from 'react';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { Calculator } from './components/Calculator';
import { UnitConverter } from './components/UnitConverter';
import { EquationSolver } from './components/EquationSolver';
import { ThemeSelector } from './components/ThemeSelector';
import { MathReference } from './components/MathReference';
import { History } from './components/History';
import { Calculator as CalculatorIcon, Settings, BookOpen, RotateCcw, Ruler, Sigma } from 'lucide-react';

const AppContent: React.FC = () => {
  const { currentTheme } = useTheme();
  const [activeTab, setActiveTab] = useState('calculator');
  const [calculations, setCalculations] = useState<string[]>([]);

  const addToHistory = (calculation: string) => {
    setCalculations(prev => [...prev, calculation]);
  };

  const clearHistory = () => {
    setCalculations([]);
  };

  const tabs = [
    { id: 'calculator', name: 'Calculator', icon: CalculatorIcon },
    { id: 'converter', name: 'Unit Converter', icon: Ruler },
    { id: 'solver', name: 'Equation Solver', icon: Sigma },
    { id: 'reference', name: 'Math Reference', icon: BookOpen },
    { id: 'history', name: 'History', icon: RotateCcw },
    { id: 'themes', name: 'Themes', icon: Settings },
  ];

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'calculator':
        return <Calculator onAddToHistory={addToHistory} />;
      case 'converter':
        return <UnitConverter />;
      case 'solver':
        return <EquationSolver />;
      case 'reference':
        return <MathReference />;
      case 'history':
        return <History calculations={calculations} onClear={clearHistory} />;
      case 'themes':
        return <ThemeSelector />;
      default:
        return <Calculator onAddToHistory={addToHistory} />;
    }
  };

  return (
    <div 
      className="min-h-screen transition-colors duration-300"
      style={{ backgroundColor: currentTheme.background }}
    >
      {/* Header */}
      <div 
        className="border-b shadow-sm"
        style={{ backgroundColor: currentTheme.surface, borderColor: currentTheme.border }}
      >
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div 
                className="p-2 rounded-lg"
                style={{ backgroundColor: currentTheme.primary }}
              >
                <CalculatorIcon size={24} color="white" />
              </div>
              <h1 className="text-2xl font-bold" style={{ color: currentTheme.text }}>
                MathHub Pro
              </h1>
            </div>
            <div className="hidden md:flex items-center gap-4">
              <span className="text-sm" style={{ color: currentTheme.textSecondary }}>
                Multi-functional Math Suite
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-1">
            <div 
              className="p-4 rounded-2xl shadow-lg sticky top-6"
              style={{ backgroundColor: currentTheme.surface, border: `1px solid ${currentTheme.border}` }}
            >
              <h3 className="text-lg font-semibold mb-4" style={{ color: currentTheme.text }}>
                Tools
              </h3>
              <nav className="space-y-2">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center gap-3 p-3 rounded-lg text-left transition-all duration-200 transform hover:scale-105 ${
                        activeTab === tab.id ? 'shadow-md' : ''
                      }`}
                      style={{
                        backgroundColor: activeTab === tab.id ? currentTheme.primary : 'transparent',
                        color: activeTab === tab.id ? 'white' : currentTheme.text,
                      }}
                    >
                      <Icon size={18} />
                      <span className="font-medium">{tab.name}</span>
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="animate-fadeIn">
              {renderActiveComponent()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;